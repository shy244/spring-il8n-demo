if (typeof seajs === "undefined") {
	throw "LUMI requires seajs to be loaded";
}

var LUMI = (function(undefined) {
	var M;
	M = {
		version: 1.0,
		config: function(options) {
			var basePath = options.resPath || "";
			basePath += (options.deviceType && options.deviceType=='mobile')?'mobile/scripts/':'pc/scripts/';
			var opt = {
				base: basePath,
				charset: 'utf-8',
				timeout: 20000,
				locale: 'cn',
				deviceType:'pc', // pc or mobile
				alias: {
				},
				preload: []
			}
			M.mix(opt, options);
			if (opt.deviceType == 'pc' && typeof jQuery === "undefined") {
				throw "LUMI requires jQuery to be loaded on PC.";
			}
			M.config = opt;
			seajs.config(opt);
		}
	};
	return M;
})();

// mix
(function(M) {
	mix(M, {
		mix: function(r, s, ov) {
			mix(r, s, ov);
		}
	});

	function mix(r, s, ov) {
		if (!s || !r) {
			return r;
		}
		if (ov === undefined) {
			ov = true;
		}

		for (var k in s) {
			if (!r[k]) {
				r[k] = s[k];
			}
			if (ov && r[k]) {
				r[k] = _mix(k, r, s, ov);
			}
		}
		return r;
	}

	function _mix(k, r, s, ov) {
		if (s[k].constructor != Object) {
			return s[k];
		}
		return mix(r[k], s[k], ov);
	}
})(LUMI);

// Date util
(function(M) {
	M.mix(M, {
		date2str: function(date,fmt) {
			var o = {
			        "M+": date.getMonth() + 1, //月份   
			        "d+": date.getDate(), //日   
			        "h+": date.getHours(), //小时   
			        "m+": date.getMinutes(), //分   
			        "s+": date.getSeconds(), //秒   
			        "q+": Math.floor((date.getMonth() + 3) / 3), //季度   
			        "S": date.getMilliseconds() //毫秒   
			 };
			 if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
			 for (var k in o){
				 if (new RegExp("(" + k + ")").test(fmt)){
					 fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
				 }
			 }
			 return fmt;
		},
		str2date:function(str){
			if(!str){
				return new Date();
			}
			return new Date(Date.parse(str.replace(/-/g, "/")));
		},
		getBeforeNDay:function(date,n){
			if(!date || M.isString(date)){
				date = M.str2date(date);
			}
			var nday = new Date(date.getTime() - n*1000*60*60*24);
		    return M.date2str(nday,'yyyy-MM-dd');
		}
	});

})(LUMI);

// type util
(function(M) {
	M.mix(M, {
		isArray: function(arr) {
			return (arr.constructor == Array)
		},
		isObject: function(obj) {
			return (arr.constructor == Object)
		},
		isString: function(str) {
			return (typeof str == "string");
		},
		isNumber: function(num) {
			return (typeof num == "number");
		},
		isBoolean: function(bol) {
			return (typeof bol == "boolean");
		},
		isNull: function(obj) {
			return (null == obj);
		},
		isUndefined: function(obj) {
			return (undefined == obj);
		},
		isFunction: function(func) {
			return (typeof func == "function");
		},
		isEmptyObject: function(obj) {
			if (!obj) {
				return true;
			}
			for (var key in obj) {
				if (typeof obj[key] != "undefined") {
					return false;
				}
			}
			return true;
		}
	});

})(LUMI);

// Module
(function(M) {
	function requireJsFun(name, success) {
		// 1.load module
		seajs.use(name, function() {
			// 2.load success,excute callback
			var exports = [];
			exports.push(M);
			for (var i = 0, len = arguments.length; i < len; i++) {
				exports.push(arguments[i]);
			}
			if (M.isFunction(success)) {
				success.apply(this, exports);
			}
		});
	}
	M.mix(M, {
		use: function(name, success) {
			// LUMI.use([],function(){});
			if (M.isArray(name)) {
				requireJsFun(name, success);
			}
			// LUMI.use('',function(){});
			if (M.isString(name)) {
				requireJsFun([name], success);
			}
		}
	});
})(LUMI);